<?php
$conn = mysqli_connect('localhost','root','1234','capstone') or die(mysqli_error());
?>