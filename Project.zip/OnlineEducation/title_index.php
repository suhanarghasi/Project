				
								<div class="row-fluid">

						<div class="span12">
						
						</div>	
													
							</div>
							<div class="row-fluid">

						<div class="span4">
						<img class="index_logo" src="admin/images/RVCE.png">
						</div>	
						<div class="span8">
						
								<div class="title">
							<p class="RVCE"></p>
							<h3>

							<p>Online Education</p>
						
							</h3>		
						</div>
			
						</div>							
							</div>
				
				<div class="row-fluid">

						<div class="span12">
						<br>
								<div class="motto">
												<p></p>
												<p></p>
												<p></p>
								</div>		
						</div>		
				</div>